package attendance;

public class Person{
        private String name;
        private String ID;
        private String ClassName;
        private boolean status;

        Person(String name, String ID, String ClassName, boolean status) {
            this.name = name;
            this.ID = ID;
            this.ClassName = ClassName;
            this.status = status;
        }

    }