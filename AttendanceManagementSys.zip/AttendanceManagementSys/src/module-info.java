/**
 * 
 */
/**
 * @author Win11
 *
 */

module AttendanceManagementSys {
	requires java.sql;
	requires java.desktop;
	requires java.naming;
}