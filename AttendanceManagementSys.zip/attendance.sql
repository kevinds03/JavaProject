-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2023 at 04:33 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `classroom`
--

CREATE TABLE `classroom` (
  `class` varchar(3) NOT NULL,
  `time` datetime DEFAULT NULL,
  `course` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `classroom`
--

INSERT INTO `classroom` (`class`, `time`, `course`) VALUES
('A01', '2023-01-09 09:00:00', 'Object Oriented Programming'),
('B01', '2023-01-10 13:00:00', 'Data Structure');

-- --------------------------------------------------------

--
-- Table structure for table `lecturers`
--

CREATE TABLE `lecturers` (
  `lid` varchar(5) NOT NULL,
  `lec_name` char(100) DEFAULT NULL,
  `class` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lecturers`
--

INSERT INTO `lecturers` (`lid`, `lec_name`, `class`) VALUES
('LEC14', 'Budi', 'B01'),
('LEC22', 'Adi', 'A01');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `sid` varchar(10) NOT NULL,
  `s_name` char(100) DEFAULT NULL,
  `class` varchar(3) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`sid`, `s_name`, `class`, `status`) VALUES
('25019591', 'KELSEN RAVILI', 'B01', 0),
('25019593', 'GRACELLA NOVELIORA', 'B01', 0),
('25019594', 'MICHAEL ANTHONY ASLAN', 'B01', 0),
('25019754', 'Kelvin', 'C11', 0),
('25019768', 'DAFFA GUSTI RAMADHANY', 'A01', 0),
('25020109', 'CELINE WONG', 'B01', 0),
('25020112', 'JOSEPH CRISTIAN LUBIS', 'A01', 0),
('25020115', 'LAWYENSKI', 'A01', 1),
('25020127', 'BRYANT LEE', 'A01', 0),
('25020157', 'FATIN NURHALISA ROZSIDHY', 'A01', 0),
('25020201', 'GHALIH YULIO ANANDA', 'A01', 0),
('25020275', 'GILANG KURNIAWAN', 'B01', 0),
('25020280', 'ADNAN FAIKAR RASHIF', 'B01', 0),
('25020300', 'ABYAN FARREL MUZAKKI', 'A01', 1),
('25020347', 'CARINA', 'A01', 0),
('25020360', 'KHARISMA DWI UTAMI', 'B01', 0),
('25020435', 'EYZAR HERMANIO', 'A01', 0),
('25020452', 'NASYWA MARZUQA', 'B01', 0),
('25020453', 'KRISANDY RIVERA', 'A01', 1),
('25020938', 'BRYAN ALEXANDER TAMA', 'B01', 0),
('25401227', 'DAVID TIMOTHY', 'B01', 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vstudent1`
-- (See below for the actual view)
--
CREATE TABLE `vstudent1` (
`sid` varchar(10)
,`s_name` char(100)
,`course` char(100)
);

-- --------------------------------------------------------

--
-- Structure for view `vstudent1`
--
DROP TABLE IF EXISTS `vstudent1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vstudent1`  AS SELECT `s`.`sid` AS `sid`, `s`.`s_name` AS `s_name`, `c`.`course` AS `course` FROM (`students` `s` join `classroom` `c` on(`s`.`class` = `c`.`class`)) WHERE `c`.`class` like 'A01' ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classroom`
--
ALTER TABLE `classroom`
  ADD PRIMARY KEY (`class`);

--
-- Indexes for table `lecturers`
--
ALTER TABLE `lecturers`
  ADD PRIMARY KEY (`lid`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`sid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
